/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.registration;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class RegistrationTest {
    
    public RegistrationTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of CheckUserName method, of class Registration.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("CheckUserName");
        Registration instance = new Registration();
        instance.CheckUserName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of CheckPassword method, of class Registration.
     */
    @Test
    public void testCheckPassword() {
        System.out.println("CheckPassword");
        String Password = "";
        Registration instance = new Registration();
        boolean expResult = false;
        boolean result = instance.CheckPassword(Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of CheckcellphoneNumber method, of class Registration.
     */
    @Test
    public void testCheckcellphoneNumber() {
        System.out.println("CheckcellphoneNumber");
        String cellphoneNumber = "";
        Registration instance = new Registration();
        boolean expResult = false;
        boolean result = instance.CheckcellphoneNumber(cellphoneNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getcellphoneNumber method, of class Registration.
     */
    @Test
    public void testGetcellphoneNumber() {
        System.out.println("getcellphoneNumber");
        Registration instance = new Registration();
        String expResult = "";
        String result = instance.getcellphoneNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of RegisterUser method, of class Registration.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("RegisterUser");
        Registration instance = new Registration();
        instance.RegisterUser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Registration.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Registration.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
