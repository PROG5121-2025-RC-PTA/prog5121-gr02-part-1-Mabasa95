/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
 
package com.mycompany.registration;
import javax.swing.*;

/**
 *
 * @author RC_Student_lab
 */
public class Registration {
     public  String Username,Password;
     public  String cellphoneNumber;
    //creating CheckUsername method 
    public void CheckUserName(){
    //these are the conditions that must be met in order for username to be considered 
        boolean Underscore=Username.contains("_");
        if(Underscore==true && Username.length()<=5){
            JOptionPane.showMessageDialog(null,"username successfully captured");
        }else{
          JOptionPane.showMessageDialog(null,"Username is not correctly formated please ensure that your username contains underscore and no more than five characters in length ");
             
         Username=JOptionPane.showInputDialog("Enter user name");
         //CALL THE METHOD UNTIL THE USERRNAME IS CORRECT /VALID
         CheckUserName();
        }
        
        
    }
    //method to check Password
    public boolean CheckPassword (String Password){
        boolean hasUppercase=false,hasDigit=false, hasSpecialChar=false;
                //define special characters
                String SpecialChar="~!@#$%^&*()_+=<>?/{}[]|;:'\",.";
                 //Check each character in password
    for (char ch:Password.toCharArray()){
    if (Character.isUpperCase(ch))hasUppercase=true;
    if (Character.isDigit(ch))hasDigit=true;
    if (SpecialChar.contains(String.valueOf(ch)))hasSpecialChar=true;
    }
    //validate all conditions
    
    return Password.length()>=8 && hasUppercase && hasDigit && hasSpecialChar;
    }
    
    //method to Check cellphoneNumber
    public boolean CheckcellphoneNumber (String cellphoneNumber){
     String pattern = "^\\+d{1,3}\\d{7,10}$";
     //starts with + followed 2 digits(country code), then 9 digits
     
     if (cellphoneNumber.matches(pattern)) {
        System.out.println(" cellphoneNumber successfully added");
        return true;
     } else{
         System.out.println("cellphoneNumber incorrectly formatted or does not contain international code");
         return false;
     }
    }
    
    public String getcellphoneNumber (){
            return cellphoneNumber;

 
}

    //creating a method called RegisterUser
public void RegisterUser(){
    
    //declaring variable
    //prompt the user to enter username
   Username=JOptionPane.showInputDialog("Enter username");
   CheckUserName();//calling the method to check
   //prompt the user to enter password
      Password=JOptionPane.showInputDialog("Enter user Password");
      //prompt the user to enter cellphone
      cellphoneNumber=JOptionPane.showInputDialog("Enter cellphoneNumber");
      
      
}
    public static  void main(String[] args) {
    //calling method Registeruser
    Registration usersign_in =new Registration();
  usersign_in.RegisterUser(); 
    }
    }
