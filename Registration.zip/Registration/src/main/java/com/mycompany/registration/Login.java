/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;
import javax.swing.*;
import java.util.Map;

/**
 *
 * @author RC_Student_lab
 */
public class Login {
     private Map<String, String> users; // Reference to the registered users

    public Login(Map<String, String> users) {
        this.users = users;
    }

    // Method for user login
    public void LoginUser() {
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");
        String cellphoneNumber=JOptionPane.showInputDialog("Enter your cellphone number");

        if (users.containsKey(username) && users.get(username).equals(password)) {
            JOptionPane.showMessageDialog(null, "Login successful!");
        } else {
            JOptionPane.showMessageDialog(null, "Invalid credentials. Please try again.");
        }
    }
}

